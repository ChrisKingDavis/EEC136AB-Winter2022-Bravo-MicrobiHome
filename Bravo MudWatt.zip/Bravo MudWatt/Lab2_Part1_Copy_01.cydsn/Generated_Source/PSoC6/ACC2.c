/***************************************************************************//**
* \file ACC2.c
* \version 2.0
*
*  This file provides the source code to the API for the I2C Component.
*
********************************************************************************
* \copyright
* Copyright 2016-2017, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "ACC2.h"
#include "sysint/cy_sysint.h"
#include "cyfitter_sysint.h"
#include "cyfitter_sysint_cfg.h"


#if defined(__cplusplus)
extern "C" {
#endif

/***************************************
*     Global variables
***************************************/

/** ACC2_initVar indicates whether the ACC2
*  component has been initialized. The variable is initialized to 0
*  and set to 1 the first time ACC2_Start() is called.
*  This allows  the component to restart without reinitialization
*  after the first call to the ACC2_Start() routine.
*
*  If re-initialization of the component is required, then the
*  ACC2_Init() function can be called before the
*  ACC2_Start() or ACC2_Enable() function.
*/
uint8_t ACC2_initVar = 0U;

/** The instance-specific configuration structure.
* The pointer to this structure should be passed to Cy_SCB_I2C_Init function
* to initialize component with GUI selected settings.
*/
cy_stc_scb_i2c_config_t const ACC2_config =
{
    .i2cMode    = CY_SCB_I2C_MASTER_SLAVE,

    .useRxFifo = false,
    .useTxFifo = false,

    .slaveAddress        = 0x8U,
    .slaveAddressMask    = 0xFEU,
    .acceptAddrInFifo    = false,
    .ackGeneralAddr      = false,

    .enableWakeFromSleep = false
};

/** The instance-specific context structure.
* It is used while the driver operation for internal configuration and
* data keeping for the I2C. The user should not modify anything in this
* structure.
*/
cy_stc_scb_i2c_context_t ACC2_context;


/*******************************************************************************
* Function Name: ACC2_Start
****************************************************************************//**
*
* Invokes ACC2_Init() and ACC2_Enable().
* Also configures interrupt and low and high oversampling phases.
* After this function call the component is enabled and ready for operation.
* This is the preferred method to begin component operation.
*
* \globalvars
* \ref ACC2_initVar - used to check initial configuration,
* modified  on first function call.
*
*******************************************************************************/
void ACC2_Start(void)
{
    if (0U == ACC2_initVar)
    {
        /* Configure component */
        (void) Cy_SCB_I2C_Init(ACC2_HW, &ACC2_config, &ACC2_context);

    #if (ACC2_ENABLE_MASTER)
        /* Configure desired data rate */
        (void) Cy_SCB_I2C_SetDataRate(ACC2_HW, ACC2_DATA_RATE_HZ, ACC2_CLK_FREQ_HZ);

        #if (ACC2_MANUAL_SCL_CONTROL)
            Cy_SCB_I2C_MasterSetLowPhaseDutyCycle (ACC2_HW, ACC2_LOW_PHASE_DUTY_CYCLE);
            Cy_SCB_I2C_MasterSetHighPhaseDutyCycle(ACC2_HW, ACC2_HIGH_PHASE_DUTY_CYCLE);
        #endif /* (ACC2_MANUAL_SCL_CONTROL) */
    #endif /* (ACC2_ENABLE_MASTER) */

        /* Hook interrupt service routine */
    #if defined(ACC2_SCB_IRQ__INTC_ASSIGNED)
        (void) Cy_SysInt_Init(&ACC2_SCB_IRQ_cfg, &ACC2_Interrupt);
    #endif /* (ACC2_SCB_IRQ__INTC_ASSIGNED) */

        ACC2_initVar = 1U;
    }

    /* Enable interrupt in NVIC */
#if defined(ACC2_SCB_IRQ__INTC_ASSIGNED)
    NVIC_EnableIRQ((IRQn_Type) ACC2_SCB_IRQ_cfg.intrSrc);
#endif /* (ACC2_SCB_IRQ__INTC_ASSIGNED) */

    Cy_SCB_I2C_Enable(ACC2_HW);
}

#if defined(__cplusplus)
}
#endif


/* [] END OF FILE */
