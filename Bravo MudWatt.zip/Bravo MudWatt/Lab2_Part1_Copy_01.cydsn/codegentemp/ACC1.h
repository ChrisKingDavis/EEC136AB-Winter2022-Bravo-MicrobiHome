/***************************************************************************//**
* \file ACC1.c
* \version 2.0
*
*  This file provides constants and parameter values for the I2C component.
*
********************************************************************************
* \copyright
* Copyright 2016-2017, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(ACC1_CY_SCB_I2C_PDL_H)
#define ACC1_CY_SCB_I2C_PDL_H

#include "cyfitter.h"
#include "scb/cy_scb_i2c.h"

#if defined(__cplusplus)
extern "C" {
#endif

/***************************************
*   Initial Parameter Constants
****************************************/

#define ACC1_MODE               (0x2U)
#define ACC1_MODE_SLAVE_MASK    (0x1U)
#define ACC1_MODE_MASTER_MASK   (0x2U)

#define ACC1_ENABLE_SLAVE       (0UL != (ACC1_MODE & ACC1_MODE_SLAVE_MASK))
#define ACC1_ENABLE_MASTER      (0UL != (ACC1_MODE & ACC1_MODE_MASTER_MASK))
#define ACC1_MANUAL_SCL_CONTROL (0U)


/***************************************
*        Function Prototypes
***************************************/
/**
* \addtogroup group_general
* @{
*/
/* Component only APIs. */
void ACC1_Start(void);

/* Basic functions. */
__STATIC_INLINE cy_en_scb_i2c_status_t ACC1_Init(cy_stc_scb_i2c_config_t const *config);
__STATIC_INLINE void ACC1_DeInit (void);
__STATIC_INLINE void ACC1_Enable (void);
__STATIC_INLINE void ACC1_Disable(void);

/* Data rate configuration functions. */
__STATIC_INLINE uint32_t ACC1_SetDataRate(uint32_t dataRateHz, uint32_t scbClockHz);
__STATIC_INLINE uint32_t ACC1_GetDataRate(uint32_t scbClockHz);

/* Register callbacks. */
__STATIC_INLINE void ACC1_RegisterEventCallback(cy_cb_scb_i2c_handle_events_t callback);
#if (ACC1_ENABLE_SLAVE)
__STATIC_INLINE void ACC1_RegisterAddrCallback (cy_cb_scb_i2c_handle_addr_t callback);
#endif /* (ACC1_ENABLE_SLAVE) */

/* Configuration functions. */
#if (ACC1_ENABLE_SLAVE)
__STATIC_INLINE void     ACC1_SlaveSetAddress(uint8_t addr);
__STATIC_INLINE uint32_t ACC1_SlaveGetAddress(void);
__STATIC_INLINE void     ACC1_SlaveSetAddressMask(uint8_t addrMask);
__STATIC_INLINE uint32_t ACC1_SlaveGetAddressMask(void);
#endif /* (ACC1_ENABLE_SLAVE) */

#if (ACC1_ENABLE_MASTER)
__STATIC_INLINE void ACC1_MasterSetLowPhaseDutyCycle (uint32_t clockCycles);
__STATIC_INLINE void ACC1_MasterSetHighPhaseDutyCycle(uint32_t clockCycles);
#endif /* (ACC1_ENABLE_MASTER) */

/* Bus status. */
__STATIC_INLINE bool     ACC1_IsBusBusy(void);

/* Slave functions. */
#if (ACC1_ENABLE_SLAVE)
__STATIC_INLINE uint32_t ACC1_SlaveGetStatus(void);

__STATIC_INLINE void     ACC1_SlaveConfigReadBuf(uint8_t *buffer, uint32_t size);
__STATIC_INLINE void     ACC1_SlaveAbortRead(void);
__STATIC_INLINE uint32_t ACC1_SlaveGetReadTransferCount(void);
__STATIC_INLINE uint32_t ACC1_SlaveClearReadStatus(void);

__STATIC_INLINE void     ACC1_SlaveConfigWriteBuf(uint8_t *buffer, uint32_t size);
__STATIC_INLINE void     ACC1_SlaveAbortWrite(void);
__STATIC_INLINE uint32_t ACC1_SlaveGetWriteTransferCount(void);
__STATIC_INLINE uint32_t ACC1_SlaveClearWriteStatus(void);
#endif /* (ACC1_ENABLE_SLAVE) */

/* Master interrupt processing functions. */
#if (ACC1_ENABLE_MASTER)
__STATIC_INLINE uint32_t ACC1_MasterGetStatus(void);

__STATIC_INLINE cy_en_scb_i2c_status_t ACC1_MasterRead(cy_stc_scb_i2c_master_xfer_config_t *xferConfig);
__STATIC_INLINE void ACC1_MasterAbortRead(void);
__STATIC_INLINE cy_en_scb_i2c_status_t ACC1_MasterWrite(cy_stc_scb_i2c_master_xfer_config_t *xferConfig);
__STATIC_INLINE void ACC1_MasterAbortWrite(void);
__STATIC_INLINE uint32_t ACC1_MasterGetTransferCount(void);

/* Master manual processing functions. */
__STATIC_INLINE cy_en_scb_i2c_status_t ACC1_MasterSendStart(uint32_t address, cy_en_scb_i2c_direction_t bitRnW, uint32_t timeoutMs);
__STATIC_INLINE cy_en_scb_i2c_status_t ACC1_MasterSendReStart(uint32_t address, cy_en_scb_i2c_direction_t bitRnW, uint32_t timeoutMs);
__STATIC_INLINE cy_en_scb_i2c_status_t ACC1_MasterSendStop(uint32_t timeoutMs);
__STATIC_INLINE cy_en_scb_i2c_status_t ACC1_MasterReadByte(cy_en_scb_i2c_command_t ackNack, uint8_t *byte, uint32_t timeoutMs);
__STATIC_INLINE cy_en_scb_i2c_status_t ACC1_MasterWriteByte(uint8_t byte, uint32_t timeoutMs);
#endif /* (ACC1_ENABLE_MASTER) */

/* Interrupt handler. */
__STATIC_INLINE void ACC1_Interrupt(void);
/** @} group_general */


/***************************************
*    Variables with External Linkage
***************************************/
/**
* \addtogroup group_globals
* @{
*/
extern uint8_t ACC1_initVar;
extern cy_stc_scb_i2c_config_t const ACC1_config;
extern cy_stc_scb_i2c_context_t ACC1_context;
/** @} group_globals */


/***************************************
*         Preprocessor Macros
***************************************/
/**
* \addtogroup group_macros
* @{
*/
/** The pointer to the base address of the SCB instance */
#define ACC1_HW     ((CySCB_Type *) ACC1_SCB__HW)

/** The desired data rate in Hz */
#define ACC1_DATA_RATE_HZ      (100000U)

/** The frequency of the clock used by the Component in Hz */
#define ACC1_CLK_FREQ_HZ       (1562500U)

/** The number of Component clocks used by the master to generate the SCL
* low phase. This number is calculated by GUI based on the selected data rate.
*/
#define ACC1_LOW_PHASE_DUTY_CYCLE   (8U)

/** The number of Component clocks used by the master to generate the SCL
* high phase. This number is calculated by GUI based on the selected data rate.
*/
#define ACC1_HIGH_PHASE_DUTY_CYCLE  (8U)
/** @} group_macros */


/***************************************
*    In-line Function Implementation
***************************************/

/*******************************************************************************
* Function Name: ACC1_Init
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_Init() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_i2c_status_t ACC1_Init(cy_stc_scb_i2c_config_t const *config)
{
    return Cy_SCB_I2C_Init(ACC1_HW, config, &ACC1_context);
}


/*******************************************************************************
*  Function Name: ACC1_DeInit
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_DeInit() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void ACC1_DeInit(void)
{
    Cy_SCB_I2C_DeInit(ACC1_HW);
}


/*******************************************************************************
* Function Name: ACC1_Enable
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_Enable() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void ACC1_Enable(void)
{
    Cy_SCB_I2C_Enable(ACC1_HW);
}


/*******************************************************************************
* Function Name: ACC1_Disable
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_Disable() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void ACC1_Disable(void)
{
    Cy_SCB_I2C_Disable(ACC1_HW, &ACC1_context);
}


/*******************************************************************************
* Function Name: ACC1_SetDataRate
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SetDataRate() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t ACC1_SetDataRate(uint32_t dataRateHz, uint32_t scbClockHz)
{
    return Cy_SCB_I2C_SetDataRate(ACC1_HW, dataRateHz, scbClockHz);
}


/*******************************************************************************
* Function Name: ACC1_GetDataRate
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_GetDataRate() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t ACC1_GetDataRate(uint32_t scbClockHz)
{
    return Cy_SCB_I2C_GetDataRate(ACC1_HW, scbClockHz);
}


/*******************************************************************************
* Function Name: ACC1_RegisterEventCallback
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_RegisterEventCallback() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void ACC1_RegisterEventCallback(cy_cb_scb_i2c_handle_events_t callback)
{
    Cy_SCB_I2C_RegisterEventCallback(ACC1_HW, callback, &ACC1_context);
}


#if (ACC1_ENABLE_SLAVE)
/*******************************************************************************
* Function Name: ACC1_RegisterAddrCallback
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_RegisterAddrCallback() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void ACC1_RegisterAddrCallback(cy_cb_scb_i2c_handle_addr_t callback)
{
    Cy_SCB_I2C_RegisterAddrCallback(ACC1_HW, callback, &ACC1_context);
}
#endif /* (ACC1_ENABLE_SLAVE) */


/*******************************************************************************
* Function Name: ACC1_IsBusBusy
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_IsBusBusy() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE bool ACC1_IsBusBusy(void)
{
    return Cy_SCB_I2C_IsBusBusy(ACC1_HW);
}


#if (ACC1_ENABLE_SLAVE)
/*******************************************************************************
* Function Name: ACC1_SlaveSetAddress
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveGetAddress() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void ACC1_SlaveSetAddress(uint8_t addr)
{
    Cy_SCB_I2C_SlaveSetAddress(ACC1_HW, addr);
}


/*******************************************************************************
* Function Name: ACC1_SlaveGetAddress
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveGetAddress() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t ACC1_SlaveGetAddress(void)
{
    return Cy_SCB_I2C_SlaveGetAddress(ACC1_HW);
}


/*******************************************************************************
* Function Name: ACC1_SlaveSetAddressMask
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveSetAddressMask() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void ACC1_SlaveSetAddressMask(uint8_t addrMask)
{
    Cy_SCB_I2C_SlaveSetAddressMask(ACC1_HW, addrMask);
}


/*******************************************************************************
* Function Name: ACC1_SlaveGetAddressMask
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveGetAddressMask() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t ACC1_SlaveGetAddressMask(void)
{
    return Cy_SCB_I2C_SlaveGetAddressMask(ACC1_HW);
}
#endif /* (ACC1_ENABLE_SLAVE) */

#if (ACC1_ENABLE_MASTER)
/*******************************************************************************
* Function Name: ACC1_MasterSetLowPhaseDutyCycle
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterSetLowPhaseDutyCycle() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void ACC1_MasterSetLowPhaseDutyCycle(uint32_t clockCycles)
{
    Cy_SCB_I2C_MasterSetLowPhaseDutyCycle(ACC1_HW, clockCycles);
}


/*******************************************************************************
* Function Name: ACC1_MasterSetHighPhaseDutyCycle
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterSetHighPhaseDutyCycle() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void ACC1_MasterSetHighPhaseDutyCycle(uint32_t clockCycles)
{
    Cy_SCB_I2C_MasterSetHighPhaseDutyCycle(ACC1_HW, clockCycles);
}
#endif /* (ACC1_ENABLE_MASTER) */


#if (ACC1_ENABLE_SLAVE)
/*******************************************************************************
* Function Name: ACC1_SlaveGetStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveGetStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t ACC1_SlaveGetStatus(void)
{
    return Cy_SCB_I2C_SlaveGetStatus(ACC1_HW, &ACC1_context);
}


/*******************************************************************************
* Function Name: ACC1_SlaveConfigReadBuf
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveConfigReadBuf() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void ACC1_SlaveConfigReadBuf(uint8_t *buffer, uint32_t size)
{
    Cy_SCB_I2C_SlaveConfigReadBuf(ACC1_HW, buffer, size, &ACC1_context);
}


/*******************************************************************************
* Function Name: ACC1_SlaveAbortRead
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveAbortRead() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void ACC1_SlaveAbortRead(void)
{
    Cy_SCB_I2C_SlaveAbortRead(ACC1_HW, &ACC1_context);
}


/*******************************************************************************
* Function Name: ACC1_SlaveGetReadTransferCount
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveGetReadTransferCount() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t ACC1_SlaveGetReadTransferCount(void)
{
    return Cy_SCB_I2C_SlaveGetReadTransferCount(ACC1_HW, &ACC1_context);
}


/*******************************************************************************
* Function Name: ACC1_SlaveClearReadStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveClearReadStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t ACC1_SlaveClearReadStatus(void)
{
    return Cy_SCB_I2C_SlaveClearReadStatus(ACC1_HW, &ACC1_context);
}


/*******************************************************************************
* Function Name: ACC1_SlaveConfigWriteBuf
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveConfigWriteBuf() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void ACC1_SlaveConfigWriteBuf(uint8_t *buffer, uint32_t size)
{
    Cy_SCB_I2C_SlaveConfigWriteBuf(ACC1_HW, buffer, size, &ACC1_context);
}


/*******************************************************************************
* Function Name: ACC1_SlaveAbortWrite
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveAbortWrite() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void ACC1_SlaveAbortWrite(void)
{
    Cy_SCB_I2C_SlaveAbortWrite(ACC1_HW, &ACC1_context);
}


/*******************************************************************************
* Function Name: ACC1_SlaveGetWriteTransferCount
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveGetWriteTransferCount() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t ACC1_SlaveGetWriteTransferCount(void)
{
    return Cy_SCB_I2C_SlaveGetWriteTransferCount(ACC1_HW, &ACC1_context);
}


/*******************************************************************************
* Function Name: ACC1_SlaveClearWriteStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveClearWriteStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t ACC1_SlaveClearWriteStatus(void)
{
    return Cy_SCB_I2C_SlaveClearWriteStatus(ACC1_HW, &ACC1_context);
}
#endif /* (ACC1_ENABLE_SLAVE) */


#if (ACC1_ENABLE_MASTER)
/*******************************************************************************
* Function Name: ACC1_MasterGetStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterGetStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t ACC1_MasterGetStatus(void)
{
    return Cy_SCB_I2C_MasterGetStatus(ACC1_HW, &ACC1_context);
}


/*******************************************************************************
* Function Name: ACC1_MasterRead
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterRead() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_i2c_status_t ACC1_MasterRead(cy_stc_scb_i2c_master_xfer_config_t *xferConfig)
{
    return Cy_SCB_I2C_MasterRead(ACC1_HW, xferConfig, &ACC1_context);
}


/*******************************************************************************
* Function Name: ACC1_MasterAbortRead
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterAbortRead() PDL driver function.
*
******************************************************************************/
__STATIC_INLINE void ACC1_MasterAbortRead(void)
{
    Cy_SCB_I2C_MasterAbortRead(ACC1_HW, &ACC1_context);
}


/*******************************************************************************
* Function Name: ACC1_MasterWrite
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterWrite() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_i2c_status_t ACC1_MasterWrite(cy_stc_scb_i2c_master_xfer_config_t *xferConfig)
{
    return Cy_SCB_I2C_MasterWrite(ACC1_HW, xferConfig, &ACC1_context);
}


/*******************************************************************************
* Function Name: ACC1_MasterAbortWrite
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterAbortWrite() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void ACC1_MasterAbortWrite(void)
{
    Cy_SCB_I2C_MasterAbortWrite(ACC1_HW, &ACC1_context);
}


/*******************************************************************************
* Function Name: ACC1_MasterGetTransferCount
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterGetTransferCount() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t ACC1_MasterGetTransferCount(void)
{
    return Cy_SCB_I2C_MasterGetTransferCount(ACC1_HW, &ACC1_context);
}


/*******************************************************************************
* Function Name: ACC1_MasterSendStart
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterSendStart() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_i2c_status_t ACC1_MasterSendStart(uint32_t address, cy_en_scb_i2c_direction_t bitRnW, uint32_t timeoutMs)
{
    return Cy_SCB_I2C_MasterSendStart(ACC1_HW, address, bitRnW, timeoutMs, &ACC1_context);
}


/*******************************************************************************
* Function Name: ACC1_MasterSendReStart
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterSendReStart() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_i2c_status_t ACC1_MasterSendReStart(uint32_t address, cy_en_scb_i2c_direction_t bitRnW, uint32_t timeoutMs)
{
    return Cy_SCB_I2C_MasterSendReStart(ACC1_HW, address, bitRnW, timeoutMs, &ACC1_context);
}


/*******************************************************************************
* Function Name: ACC1_MasterSendStop
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterSendStop() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_i2c_status_t ACC1_MasterSendStop(uint32_t timeoutMs)
{
    return Cy_SCB_I2C_MasterSendStop(ACC1_HW, timeoutMs, &ACC1_context);
}


/*******************************************************************************
* Function Name: ACC1_MasterReadByte
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterReadByte() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_i2c_status_t ACC1_MasterReadByte(cy_en_scb_i2c_command_t ackNack, uint8_t *byte, uint32_t timeoutMs)
{
    return Cy_SCB_I2C_MasterReadByte(ACC1_HW, ackNack, byte, timeoutMs, &ACC1_context);
}


/*******************************************************************************
* Function Name: ACC1_MasterWriteByte
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterWriteByte() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_i2c_status_t ACC1_MasterWriteByte(uint8_t byte, uint32_t timeoutMs)
{
    return Cy_SCB_I2C_MasterWriteByte(ACC1_HW, byte, timeoutMs, &ACC1_context);
}
#endif /* (ACC1_ENABLE_MASTER) */


/*******************************************************************************
* Function Name: ACC1_Interrupt
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_Interrupt() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void ACC1_Interrupt(void)
{
    Cy_SCB_I2C_Interrupt(ACC1_HW, &ACC1_context);
}

#if defined(__cplusplus)
}
#endif

#endif /* ACC1_CY_SCB_I2C_PDL_H */


/* [] END OF FILE */
